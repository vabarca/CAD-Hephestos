/**
 * BAM&DICE Due (Arduino Mega) pin assignments
 */

#include "pins_RAMPS_13.h"

#define FAN_PIN             9 // (Sprinter config)
#define HEATER_1_PIN       -1

#define TEMP_0_PIN          9 // ANALOG NUMBERING
#define TEMP_1_PIN         11 // ANALOG NUMBERING
